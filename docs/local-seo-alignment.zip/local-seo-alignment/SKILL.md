---
name: local-seo-alignment
description: >
  Apply 2026 local SEO and entity verification standards when auditing, optimizing, or building a local business's
  digital presence. Use this skill whenever the user mentions Google Business Profile, GBP, local SEO, NAP consistency,
  local landing pages, service schema, JSON-LD, local pack rankings, map pack, Google Maps optimization, review strategy,
  local citations, business categories, service area businesses, or any work involving aligning a website with a
  Google Business Profile. Also trigger when the user is building local landing pages, writing service page copy,
  creating schema markup, auditing business listings, managing reviews, or discussing local search rankings.
  This skill enforces entity-verification-grade rigor across data consistency, content alignment, technical schema,
  and review strategy.
---

# Local SEO & Entity Alignment Standards (2026)

Apply these standards when auditing, building, or optimizing any local business's digital presence.
The goal is a "matched" entity — where GBP, website, schema, and third-party citations speak with one voice.

## 1. NAP+W Consistency (Foundation)

Every ranking signal builds on this. If NAP+W is broken, nothing else matters.

**NAP+W = Name, Address, Phone, Website.** In 2026, extend to WhatsApp, Instagram, and booking system links.

| Data Point | Rule | Failure Consequence |
|------------|------|-------------------|
| **Business Name** | Must match legal registration + physical signage exactly. No keywords, no locations, no promotions added. | Hard suspension |
| **Address** | Identical formatting everywhere. Pick "Street" OR "St." — use it universally. | Reduced proximity confidence |
| **Phone** | Local direct line. Must match website footer AND GBP. Crawlable (not image-only). | Broken click-to-call signals |
| **Website URL** | Link to specific location/service page, not homepage (unless single-location). | Weakened geo-relevancy signal |
| **Hours** | Real-time accurate including holidays and seasonal shifts. | High-risk suspension trigger |

**Verification reality:** Google cross-references phone numbers against call patterns, addresses against postal databases and Street View imagery, and website engagement against profile engagement. Mismatches trigger automated trust drops.

## 2. Category Strategy

The primary GBP category is the single most influential local pack ranking factor (~32% of ranking signals).

**Rules:**
- Primary category = core service that drives the highest revenue percentage.
- Use Google's exact taxonomy language. If Google says "HVAC Contractor," your H1 says "HVAC Contractor" — not "Climate Control Specialists."
- Secondary categories = additional specific services. Each one needs a dedicated website page.
- Never use categories for services you don't actually provide.

**Alignment chain:**

```
GBP Primary Category → Website H1 → Title Tag → Schema @type → Service Page Content
```

Every link in this chain must use consistent terminology.

## 3. Service Mapping & Content Alignment

Google's AI analyzes whether the website "backs up" claims made on the GBP listing. Mismatches are negative signals.

**For every service listed in GBP:**
- Create a dedicated landing page with in-depth, locally relevant content
- H1/H2 headers must include the exact GBP service terminology + city modifier
- Include original photos from actual local jobs (not stock)
- Add localized testimonials from customers in that service area
- Mention specific neighborhoods, landmarks, and regional terminology

**Content silo structure:**
```
/services/
  /hvac-repair-dallas/          ← Matches GBP service "HVAC Repair"
  /ac-installation-dallas/      ← Matches GBP service "AC Installation"
  /emergency-plumber-dallas/    ← Matches GBP service "Emergency Plumbing"
```

**Avoid:**
- Generic "we serve the entire state" language
- Duplicate content across city pages (Google penalizes thin/duplicate local pages)
- Keyword stuffing — use natural language with local context

## 4. Metadata Synchronization

**Title tag formula:** `[Primary Service] in [City] | [Brand Name]`
Example: `Emergency Plumber in Dallas | ABC Plumbing`

**H1 formula:** Mirror title tag or use primary GBP category + city.
Example: `Top-Rated HVAC Contractor in Phoenix`

**Meta description:** Weave in secondary categories + local landmarks naturally. Address pain points. No keyword stuffing.

**Alignment table:**

| GBP Element | Website Element |
|-------------|----------------|
| Primary Category | H1 + Title Tag |
| Secondary Category | H2 headers on service pages |
| Service Area (zip codes/radius) | Neighborhood-specific content pages |
| Business Description | About page + homepage intro |

## 5. Local Landing Page Architecture

Each location or service-area page must contain:

- [ ] **Embedded Google Map** of the GBP listing (contact page or footer)
- [ ] **Localized keyphrases** — neighborhood names, landmarks, regional terms
- [ ] **Localized testimonials** — reviews from customers in that specific area
- [ ] **Staff profiles** with original photos of the local team
- [ ] **Storefront/location photos** — original, not stock
- [ ] **NAP in structured, crawlable text** (not buried in images)
- [ ] **Click-to-call button** with matching phone number
- [ ] **Page load < 3 seconds** on mobile (30% of mobile searches are location-based)
- [ ] **Mobile-responsive design** — immediate purchase intent users on mobile

## 6. Schema Markup (JSON-LD)

Schema is the translation layer between human content and machine understanding. JSON-LD is the only standard.

**Required schema types (nested in single `@graph` block):**

| Schema Type | Purpose | Critical Properties |
|-------------|---------|-------------------|
| `Organization` | Brand entity across all pages | `name`, `url`, `logo`, `sameAs` |
| `LocalBusiness` | Location-specific entity | Use most specific `@type` (e.g., `Dentist`, `HVACBusiness`). Include `name`, `address`, `telephone`, `geo`, `openingHours` |
| `Service` | What the business does | Nested inside `LocalBusiness`. `name`, `description`, `url`, `areaServed` |
| `hasOfferCatalog` | Full service catalog | `OfferCatalog` with `itemListElement` linking each service to its dedicated URL |

**Critical properties for 2026:**
- `areaServed` — Essential for service-area businesses without a storefront
- `knowsAbout` — Links to Wikipedia/Wikidata for E-E-A-T signals
- `sameAs` — Links to Facebook, LinkedIn, professional directories
- `geo` — Latitude/longitude for proximity matching in "near me" searches
- `@id` — Use for cross-page referencing (e.g., `"#location-catalog"`) to maintain single source of truth

For complete JSON-LD templates and implementation examples, read `references/schema-templates.md`.

## 7. Review Strategy

Reviews are a dominant relevance signal. Google looks for service keywords naturally mentioned in customer feedback.

**Sector impact of review keyword relevance on Top 10 rankings:**

| Sector | Review Keyword Impact |
|--------|----------------------|
| Real Estate | 45.4% |
| Personal Care | 26.3% |
| Construction | 22.5% |
| Events/Entertainment | 17.7% |
| Health Services | 13.1% |

**Strategy:**
- Encourage reviews that naturally mention the specific service performed + city/neighborhood
- Never script reviews — Google detects templated language
- Respond to every review (positive and negative) mentioning the service category
- Display service-specific review clusters on corresponding landing pages
- Monitor review velocity — sudden spikes or drops trigger algorithmic scrutiny

## 8. Suspension Triggers (Avoid These)

| Trigger | Risk Level | Prevention |
|---------|-----------|------------|
| Keywords in business name | **Hard suspension** | Use legal name only. Period. |
| NAP inconsistencies across directories | **Trust drop** | Audit all citations quarterly |
| Virtual office / mailbox address | **Suspension** | Use eligible physical address only |
| Hours mismatch (GBP vs. reality) | **Trust drop → suspension** | Update hours in real-time, including holidays |
| Aggressive profile edits (multiple core fields changed quickly) | **Auto-suspension** | Batch minor updates. Plan major changes carefully. |
| Multiple listings for same location | **Trust drop** | Merge or remove duplicates immediately |

## 9. Audit Checklist

### Phase 1: Core Entity Verification
- [ ] Business name matches signage + legal docs + website footer + GBP
- [ ] Address formatting identical across GBP, website, and all directories
- [ ] Primary category reflects core service / highest revenue driver
- [ ] Phone number is local, crawlable, and matches everywhere
- [ ] GBP website URL points to specific location/service page

### Phase 2: Content & Metadata Alignment
- [ ] H1/H2 headers include primary GBP category + city modifier
- [ ] Unique, in-depth page exists for every secondary service category
- [ ] Original geotagged photos (exterior, interior, team, services in action)
- [ ] Localized testimonials on each service/location page
- [ ] Title tags follow `[Service] in [City] | [Brand]` format

### Phase 3: Technical Schema Validation
- [ ] JSON-LD block contains `LocalBusiness` + `Organization` + `Service` types
- [ ] Most specific `@type` used (not generic `LocalBusiness`)
- [ ] `hasOfferCatalog` lists all services with URLs to dedicated pages
- [ ] Passes Google Rich Results Test
- [ ] `@id` linking correctly connects Service → LocalBusiness entity
- [ ] `geo` coordinates match actual business location
- [ ] Schema monitored in Google Search Console

---

*For complete JSON-LD templates with worked examples, read `references/schema-templates.md`.*
*For sector-specific ranking factor weights and audit procedures, read `references/sector-ranking-factors.md`.*
