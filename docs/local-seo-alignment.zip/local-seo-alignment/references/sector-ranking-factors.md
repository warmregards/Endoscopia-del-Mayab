# Sector-Specific Ranking Factors & Audit Procedures

## Ranking Factor Weights by Sector (2026)

| Sector | #1 Factor | Weight | #2 Factor | Weight | Review Keyword Impact |
|--------|-----------|--------|-----------|--------|----------------------|
| **Legal** | Proximity | 69.4% | Review Quality | — | 8.8% |
| **Financial Services** | Distance | 66.0% | Reviews | — | 10.9% |
| **Real Estate** | Review Keywords | 45.4% | Distance | 45.4% | 45.4% |
| **Construction** | Distance | 43.5% | Review Keywords | — | 22.5% |
| **Health Services** | Reviews | 33.4% | Review Keywords | — | 25.2% |
| **Beauty/Personal Care** | Proximity | 41.6% | Review Volume | — | 26.3% |
| **Events/Entertainment** | — | — | — | — | 17.7% |

## Sector-Specific Audit Priorities

### Legal Services

**Primary lever:** Proximity. You must rank for "near me" searches.

- Exact address with suite number matching across all directories
- Schema `@type`: `Attorney` or `LegalService` (use specific practice area if available)
- Primary category: Most specific practice area (e.g., "Personal Injury Attorney" not "Lawyer")
- Reviews: Quality over quantity. Detailed case-outcome narratives mentioning practice area
- Content: Individual pages per practice area + per jurisdiction served
- E-E-A-T: Attorney bios with `knowsAbout` linking to legal topics on Wikipedia

**Common mistake:** Using "Law Firm" as primary category when a specific practice type is available.

### Healthcare / Medical

**Primary lever:** Reviews (33.4%) and review keywords (25.2%).

- Schema `@type`: Use `Physician`, `Dentist`, `MedicalClinic`, etc. — never generic
- Primary category: Most specific medical specialty
- Reviews: Encourage patients to mention specific procedures/conditions treated
- Content: Condition-specific pages with localized content (e.g., "Pediatric Dentistry in [City]")
- HIPAA consideration: Never reference specific patient details in review responses
- Photos: Office interior, equipment, team — builds trust for healthcare decisions

**Common mistake:** Generic "Doctor" category when "Pediatrician" or "Dermatologist" is available.

### Construction / Home Services

**Primary lever:** Distance (43.5%) + review keywords (22.5%).

- Schema `@type`: `Plumber`, `Electrician`, `HVACBusiness`, `RoofingContractor`
- Service pages: Individual page per service type with before/after photo galleries
- Reviews: Encourage mention of specific service performed + neighborhood
- `areaServed`: Critical — list every city/zip code served
- Content: Project case studies with location details, materials used, timeline
- GBP Posts: Regular project completion posts with photos maintain activity signals

**Common mistake:** "General Contractor" category when specific trade categories exist.

### Real Estate

**Primary lever:** Review keyword relevance (45.4%). This is the highest review-keyword-dependent sector.

- Schema `@type`: `RealEstateAgent`
- Reviews: Actively encourage buyers/sellers to mention neighborhood, property type, and transaction type
- Content: Neighborhood guides with hyper-local data (school districts, walkability, market stats)
- Photos: Sold properties with agent, neighborhood landmarks
- GBP Posts: New listings, market updates, sold announcements
- `areaServed`: List every neighborhood and zip code, not just city-level

**Common mistake:** Neglecting review keyword strategy — in this sector it's nearly half the ranking algorithm.

### Beauty / Personal Care

**Primary lever:** Proximity (41.6%) + review volume (26.3%).

- Schema `@type`: `HairSalon`, `BeautySalon`, `DaySpa`, `NailSalon`
- Reviews: Volume matters more here than in other sectors. Systematic review requests after every appointment.
- Photos: Before/after transformations, interior ambiance, team at work
- Content: Service menu pages matching GBP services exactly
- GBP attributes: Maximize — accessibility, payment methods, amenities
- Booking integration: Link GBP to online booking system

**Common mistake:** Not maintaining review velocity. In personal care, a steady stream of recent reviews outweighs a large but stale review count.

### Financial Services

**Primary lever:** Distance (66.0%).

- Schema `@type`: `AccountingService`, `InsuranceAgency`, `FinancialService`
- Trust signals: Professional certifications in schema (`hasCredential`)
- Content: Service pages per financial product/service type
- Reviews: Encourage mention of specific service (tax preparation, insurance type, advisory)
- Compliance: Financial disclaimers on all relevant pages
- E-E-A-T: Advisor bios with credentials, professional associations

**Common mistake:** Missing professional credential markup — financial services customers heavily weight expertise signals.

## Quarterly Audit Procedure

### Month 1: Foundation Audit
1. Export all citations from major directories (Yelp, BBB, industry-specific)
2. Compare NAP+W against GBP listing — flag every inconsistency
3. Verify primary category against revenue breakdown — adjust if misaligned
4. Check GBP for duplicate listings — merge or remove
5. Validate schema with Rich Results Test — fix all errors

### Month 2: Content Audit
1. Map every GBP service to a website page — identify gaps
2. Audit H1/H2 alignment with GBP categories
3. Check title tags against `[Service] in [City] | [Brand]` format
4. Review photo inventory — flag stock photos for replacement with originals
5. Audit localized testimonials — ensure each service page has relevant reviews

### Month 3: Performance Audit
1. Pull GBP Insights: calls, direction requests, website clicks, photo views
2. Compare against previous quarter — identify trends
3. Review search queries driving GBP impressions — align content to gaps
4. Monitor review velocity and keyword content
5. Check page speed on all local landing pages (target: <3s mobile)

### Ongoing: Weekly Maintenance
- Respond to all new reviews within 48 hours
- Post to GBP at least 1x/week (project photos, offers, updates)
- Monitor for unauthorized edits to GBP listing
- Update hours for any holidays or schedule changes immediately
