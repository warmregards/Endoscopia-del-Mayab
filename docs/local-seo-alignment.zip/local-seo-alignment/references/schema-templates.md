# JSON-LD Schema Templates for Local SEO

## Complete Single-Location Template

This is the full `@graph` implementation for a single-location local business. Copy, customize, and validate.

```json
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebSite",
      "@id": "https://example.com/#website",
      "url": "https://example.com",
      "name": "ABC Plumbing",
      "publisher": {
        "@id": "https://example.com/#organization"
      }
    },
    {
      "@type": "Organization",
      "@id": "https://example.com/#organization",
      "name": "ABC Plumbing",
      "url": "https://example.com",
      "logo": {
        "@type": "ImageObject",
        "url": "https://example.com/images/logo.png",
        "width": 300,
        "height": 60
      },
      "sameAs": [
        "https://www.facebook.com/abcplumbing",
        "https://www.linkedin.com/company/abcplumbing",
        "https://www.instagram.com/abcplumbing",
        "https://www.yelp.com/biz/abc-plumbing-dallas"
      ]
    },
    {
      "@type": "Plumber",
      "@id": "https://example.com/#localbusiness",
      "name": "ABC Plumbing",
      "url": "https://example.com",
      "telephone": "+1-214-555-0123",
      "email": "info@abcplumbing.com",
      "image": "https://example.com/images/storefront.jpg",
      "priceRange": "$$",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "1234 Main Street",
        "addressLocality": "Dallas",
        "addressRegion": "TX",
        "postalCode": "75201",
        "addressCountry": "US"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": 32.7767,
        "longitude": -96.7970
      },
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
          "opens": "08:00",
          "closes": "18:00"
        },
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": "Saturday",
          "opens": "09:00",
          "closes": "14:00"
        }
      ],
      "areaServed": [
        {
          "@type": "City",
          "name": "Dallas",
          "sameAs": "https://en.wikipedia.org/wiki/Dallas"
        },
        {
          "@type": "City",
          "name": "Fort Worth",
          "sameAs": "https://en.wikipedia.org/wiki/Fort_Worth,_Texas"
        }
      ],
      "knowsAbout": [
        {
          "@type": "Thing",
          "name": "Plumbing",
          "sameAs": "https://en.wikipedia.org/wiki/Plumbing"
        },
        {
          "@type": "Thing",
          "name": "Water heater",
          "sameAs": "https://en.wikipedia.org/wiki/Water_heating"
        }
      ],
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "@id": "https://example.com/#service-catalog",
        "name": "Plumbing Services",
        "itemListElement": [
          {
            "@type": "OfferCatalog",
            "name": "Emergency Plumbing",
            "itemListElement": [
              {
                "@type": "Offer",
                "itemOffered": {
                  "@type": "Service",
                  "name": "Emergency Plumber",
                  "description": "24/7 emergency plumbing service in Dallas and Fort Worth. Burst pipes, flooding, sewer backups.",
                  "url": "https://example.com/services/emergency-plumber-dallas/",
                  "provider": {
                    "@id": "https://example.com/#localbusiness"
                  },
                  "areaServed": {
                    "@type": "City",
                    "name": "Dallas"
                  }
                }
              }
            ]
          },
          {
            "@type": "OfferCatalog",
            "name": "Water Heater Services",
            "itemListElement": [
              {
                "@type": "Offer",
                "itemOffered": {
                  "@type": "Service",
                  "name": "Water Heater Installation",
                  "description": "Tankless and traditional water heater installation in Dallas. Licensed and insured.",
                  "url": "https://example.com/services/water-heater-installation-dallas/",
                  "provider": {
                    "@id": "https://example.com/#localbusiness"
                  }
                }
              },
              {
                "@type": "Offer",
                "itemOffered": {
                  "@type": "Service",
                  "name": "Water Heater Repair",
                  "description": "Same-day water heater repair service. All brands serviced.",
                  "url": "https://example.com/services/water-heater-repair-dallas/",
                  "provider": {
                    "@id": "https://example.com/#localbusiness"
                  }
                }
              }
            ]
          }
        ]
      }
    }
  ]
}
```

## Service-Area Business (No Storefront)

For businesses that travel to customers (e.g., mobile mechanics, home cleaning):

**Key differences from standard LocalBusiness:**
- Omit `address` or mark it as hidden
- `areaServed` becomes the primary geographic signal
- Add `availableChannel` for booking methods

```json
{
  "@type": "HomeAndConstructionBusiness",
  "@id": "https://example.com/#localbusiness",
  "name": "Dallas Mobile Mechanic",
  "url": "https://example.com",
  "telephone": "+1-214-555-0456",
  "areaServed": [
    {
      "@type": "City",
      "name": "Dallas"
    },
    {
      "@type": "City",
      "name": "Plano"
    },
    {
      "@type": "City",
      "name": "Richardson"
    }
  ],
  "availableChannel": {
    "@type": "ServiceChannel",
    "serviceUrl": "https://example.com/book",
    "servicePhone": "+1-214-555-0456",
    "serviceSmsNumber": "+1-214-555-0456"
  }
}
```

## Multi-Location Template Pattern

For businesses with multiple locations, each location gets its own `LocalBusiness` entity linked to the parent `Organization`:

```json
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://example.com/#organization",
      "name": "ABC Dental Group",
      "url": "https://example.com",
      "subOrganization": [
        { "@id": "https://example.com/locations/dallas/#localbusiness" },
        { "@id": "https://example.com/locations/austin/#localbusiness" }
      ]
    },
    {
      "@type": "Dentist",
      "@id": "https://example.com/locations/dallas/#localbusiness",
      "name": "ABC Dental - Dallas",
      "url": "https://example.com/locations/dallas/",
      "parentOrganization": {
        "@id": "https://example.com/#organization"
      },
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "500 Commerce Street",
        "addressLocality": "Dallas",
        "addressRegion": "TX",
        "postalCode": "75201"
      },
      "hasOfferCatalog": {
        "@id": "https://example.com/locations/dallas/#service-catalog"
      }
    },
    {
      "@type": "Dentist",
      "@id": "https://example.com/locations/austin/#localbusiness",
      "name": "ABC Dental - Austin",
      "url": "https://example.com/locations/austin/",
      "parentOrganization": {
        "@id": "https://example.com/#organization"
      },
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "200 Congress Avenue",
        "addressLocality": "Austin",
        "addressRegion": "TX",
        "postalCode": "78701"
      },
      "hasOfferCatalog": {
        "@id": "https://example.com/locations/austin/#service-catalog"
      }
    }
  ]
}
```

**Rule:** Each location's `hasOfferCatalog` can reference a shared catalog OR have its own — use location-specific catalogs when branches offer different services.

## Common @type Values for Local Businesses

Use the most specific type available. Never default to generic `LocalBusiness`.

| Industry | Specific @type |
|----------|---------------|
| Plumbing | `Plumber` |
| HVAC | `HVACBusiness` |
| Electrician | `Electrician` |
| Dentist | `Dentist` |
| Doctor | `Physician` |
| Lawyer | `Attorney` |
| Restaurant | `Restaurant` |
| Hair Salon | `HairSalon` |
| Auto Repair | `AutoRepair` |
| Real Estate | `RealEstateAgent` |
| Veterinarian | `VeterinaryCare` |
| Gym/Fitness | `HealthClub` |
| Accounting | `AccountingService` |
| Insurance | `InsuranceAgency` |

## Validation Checklist

After implementing schema:

- [ ] Passes [Google Rich Results Test](https://search.google.com/test/rich-results)
- [ ] No errors in Google Search Console → Enhancements → Structured Data
- [ ] `@type` is most specific available (not generic `LocalBusiness`)
- [ ] `name` matches GBP business name exactly
- [ ] `address` formatting matches GBP and website footer exactly
- [ ] `telephone` matches GBP and website
- [ ] `geo` coordinates are accurate (verify on Google Maps)
- [ ] `openingHoursSpecification` matches GBP hours
- [ ] `hasOfferCatalog` lists all GBP services with correct URLs
- [ ] `sameAs` links to all verified social profiles
- [ ] `areaServed` defined for service-area businesses
- [ ] `@id` attributes enable cross-page referencing without duplicate code
